package org.example.java.repository;

import org.example.java.model.ItemPergunta;
import org.example.java.model.Prova;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ItemPerguntaRepository extends JpaRepository<ItemPergunta, Long> {

}
